
# Hyderabad Navigation System

This project provides a simple **C++ program** to calculate the shortest path(s) in the Hyderabad Metro rail network. It supports two modes of navigation:

1. **Shortest Path Between Two Stations**  
2. **Optimal Path to Visit Multiple Stations**

---

## Features

- **Graph Representation**: The metro network is represented as a graph with stations as nodes and distances as edges.
- **Shortest Path Algorithm**: Utilizes **Dijkstra's Algorithm** to find the shortest path.
- **Avoid Stations**: Users can specify stations to avoid while calculating paths.
- **Multiple Destinations**: Finds the optimal path for visiting multiple stations.

---

## How to Use

1. **Compile the Program**:
   ```bash
   g++ project2.cpp -o project2
   ```
2. **Run the Program**:
   ```bash
   ./project2
   ```

3. **Choose an Option**:
   - `1`: Find the shortest path between two stations.
   - `2`: Calculate the optimal path to visit multiple stations.
   - `3`: Exit the program.

---

## Input Examples

### Option 1: Shortest Path Between Two Stations

- **Prompt**:
  ```plaintext
  Enter start station: Miyapur
  Enter destination station: Charminar
  Enter stations to avoid (comma-separated, leave blank if none): Erragadda, Begumpet
  ```

- **Output**:
  ```plaintext
  The shortest path from Miyapur to Charminar is:
  Miyapur -> Kukatpally -> Ameerpet -> Lakdikapul -> Charminar
  Total distance: 20.4 km.
  ```

---

### Option 2: Optimal Path to Visit Multiple Stations

- **Prompt**:
  ```plaintext
  Enter start station: Miyapur
  Enter destinations (comma-separated): Charminar, LB Nagar, Secunderabad
  Enter stations to avoid (comma-separated, leave blank if none): Ameerpet
  ```

- **Output**:
  ```plaintext
  Optimal path to visit all destinations starting from Miyapur:
  Miyapur -> Secunderabad -> LB Nagar -> Charminar
  Total distance: 30.5 km.

  Detailed paths between stations:

  Path from Miyapur to Secunderabad:
  Miyapur -> Kukatpally -> Moosapet -> Mettuguda -> Secunderabad

  Path from Secunderabad to LB Nagar:
  Secunderabad -> RTC Cross Roads -> Malakpet -> LB Nagar

  Path from LB Nagar to Charminar:
  LB Nagar -> MG Bus Station -> Charminar
  ```

---

## Network Data

The network data is preloaded with the following:

- **Stations**: 50+ stations across Hyderabad.
- **Connections**: Direct links with distances (in kilometers).
- certain connections have been estimated and may not be accurate to real life connections.

## Functions and Classes

### Class: `Graph`

- **`addEdge`**: Adds a connection between two stations.
- **`dijkstra`**: Finds the shortest path using Dijkstra's algorithm.
- **`findShortestPath`**: Displays the shortest path between two stations.
- **`multipleDestinations`**: Calculates the optimal path for visiting multiple destinations.
- **Utility Functions**:
  - `toLowerCase`: Converts strings to lowercase for case-insensitive input.
  - `trim`: Removes whitespace from input strings.
  - `findStation`: Validates and retrieves station names.



## Extra Content

- There is a png file **`map.png`** that contains all the nodes with conections.
- There is a txt file containing all the list of nodes **`nodelist.txt`**.


Enjoy navigating Hyderabad with this program! 🚇
