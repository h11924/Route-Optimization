#include <iostream>
#include <unordered_map>
#include <vector>
#include <string>
#include <queue>
#include <limits>
#include <stack>
#include <iomanip>
#include <algorithm>
#include <set>
#include <sstream>

using namespace std;

const double INF = numeric_limits<double>::infinity();

struct Edge {
    string station;
    double distance;
};

class Graph {
private:
    unordered_map<string, vector<Edge>> adjList;

public:
    void addEdge(const string& station1, const string& station2, double distance) {
        adjList[station1].push_back({station2, distance});
        adjList[station2].push_back({station1, distance});
    }

    void dijkstra(
        const string& start,
        unordered_map<string, double>& distances,
        unordered_map<string, string>& previous,
        const set<string>& avoidStations = {}
    ) {
        typedef pair<double, string> P;
        priority_queue<P, vector<P>, greater<P>> pq;

        for (auto& it : adjList) {
            distances[it.first] = INF;
        }

        distances[start] = 0;
        pq.push(make_pair(0, start));

        while (!pq.empty()) {
            P current = pq.top();
            pq.pop();

            double currentDistance = current.first;
            string currentStation = current.second;

            if (currentDistance > distances[currentStation]) continue;

            for (const Edge& edge : adjList[currentStation]) {
                if (avoidStations.find(edge.station) != avoidStations.end()) continue;

                double newDistance = currentDistance + edge.distance;
                if (newDistance < distances[edge.station]) {
                    distances[edge.station] = newDistance;
                    previous[edge.station] = currentStation;
                    pq.push(make_pair(newDistance, edge.station));
                }
            }
        }
    }

    void findShortestPath(const string& start, const string& destination, const set<string>& avoidStations) {
        unordered_map<string, double> distances;
        unordered_map<string, string> previous;

        dijkstra(start, distances, previous, avoidStations);

        if (distances[destination] == INF) {
            cout << "\nNo path found from " << start << " to " << destination << ".\n";
            return;
        }

        stack<string> path;
        string current = destination;

        while (current != start) {
            path.push(current);
            current = previous[current];
        }

        path.push(start);

        cout << "\nThe shortest path from " << start << " to " << destination << " is:\n";
        while (!path.empty()) {
            cout << path.top();
            path.pop();
            if (!path.empty()) cout << " -> ";
        }

        cout << "\nTotal distance: " << fixed << setprecision(1) << distances[destination] << " km.\n";
    }

    void multipleDestinations(const string& start, const vector<string>& destinations, const set<string>& avoidStations) {
        vector<string> points = destinations;
        points.insert(points.begin(), start);

        unordered_map<string, unordered_map<string, double>> allPairDistances;
        unordered_map<string, unordered_map<string, vector<string>>> allPairPaths;

        for (const string& point : points) {
            unordered_map<string, double> distances;
            unordered_map<string, string> previous;

            dijkstra(point, distances, previous, avoidStations);

            for (const string& other : points) {
                if (point != other) {
                    allPairDistances[point][other] = distances[other];

                    vector<string> path;
                    string current = other;
                    while (current != point) {
                        path.push_back(current);
                        current = previous[current];
                    }

                    path.push_back(point);
                    reverse(path.begin(), path.end());
                    allPairPaths[point][other] = path;
                }
            }
        }

        double minTotalDistance = INF;
        vector<string> optimalOrder;

        vector<string> permutation = destinations;
        do {
            double currentDistance = allPairDistances[start][permutation.front()];

            for (size_t i = 1; i < permutation.size(); ++i) {
                currentDistance += allPairDistances[permutation[i - 1]][permutation[i]];
            }

            currentDistance += allPairDistances[permutation.back()][start];

            if (currentDistance < minTotalDistance) {
                minTotalDistance = currentDistance;
                optimalOrder = permutation;
            }
        } while (next_permutation(permutation.begin(), permutation.end()));

        if (minTotalDistance == INF) {
            cout << "\nNo valid path exists to visit all destinations.\n";
            return;
        }

        cout << "\nOptimal path to visit all destinations starting from " << start << ":\n";
        cout << start;

        for (const string& station : optimalOrder) {
            cout << " -> " << station;
        }

        cout << "\nTotal distance: " << fixed << setprecision(1) << minTotalDistance << " km.\n";

        cout << "\nDetailed paths between stations:\n";
        string currentStation = start;

        for (const string& nextStation : optimalOrder) {
            cout << "\nPath from " << currentStation << " to " << nextStation << ":\n";
            const vector<string>& path = allPairPaths[currentStation][nextStation];

            for (size_t i = 0; i < path.size(); ++i) {
                cout << path[i];
                if (i < path.size() - 1) cout << " -> ";
            }

            cout << "\n";
            currentStation = nextStation;
        }
    }

    string toLowerCase(const string& str) {
        string lowerStr = str;
        transform(lowerStr.begin(), lowerStr.end(), lowerStr.begin(), ::tolower);
        return lowerStr;
    }

    string trim(const string& str) {
        size_t start = str.find_first_not_of(" ");
        size_t end = str.find_last_not_of(" ");
        return (start == string::npos) ? "" : str.substr(start, end - start + 1);
    }

    string findStation(const string& input) {
        string trimmedInput = trim(input);
        string lowerInput = toLowerCase(trimmedInput);

        for (auto& it : adjList) {
            if (toLowerCase(it.first) == lowerInput) {
                return it.first;
            }
        }

        return "";
    }
};

int main() {
    Graph metroGraph;

    
    vector<tuple<string, string, double>> connections = {
        {"Miyapur", "JNTU", 1.2}, {"JNTU", "H B Colony", 1.2}, {"H B Colony", "Kukatpally", 1.2},
        {"Kukatpally", "Balanagar", 1.2}, {"Balanagar", "Moosapet", 1.2}, {"Moosapet", "Bharat Nagar", 1.2},
        {"Bharat Nagar", "Erragadda", 1.2}, {"Erragadda", "ESI", 1.2}, {"ESI", "S R Nagar", 1.2},
        {"S R Nagar", "Ameerpet", 1.2}, {"Ameerpet", "Punjagutta", 1.2}, {"Punjagutta", "Erra Manzil", 1.2},
        {"Erra Manzil", "Khairatabad", 1.2}, {"Khairatabad", "Lakdikapul", 1.2}, {"Lakdikapul", "Assembly", 1.2},
        {"Assembly", "Nampally", 1.2}, {"Nampally", "Gandhi Bhavan", 1.2}, 
        {"Gandhi Bhavan", "Osmania Medical College", 1.2}, 
        {"Osmania Medical College", "MG Bus Station", 1.2}, {"MG Bus Station", "Malakpet", 1.2},
        {"Malakpet", "New Market", 1.2}, {"New Market", "Moosarambagh", 1.2},
        {"Moosarambagh", "Chaitanyapuri", 1.2}, {"Chaitanyapuri", "Dilshukhnagar", 1.2},
        {"Dilshukhnagar", "LB Nagar", 1.2},
        {"JBS", "Parade Grounds", 1.2}, {"Parade Grounds", "Secunderabad", 1.2},
        {"Secunderabad", "Gandhi Hospital", 1.2}, {"Gandhi Hospital", "Ramanthapur", 1.2},
        {"Ramanthapur", "RTC Cross Roads", 1.2}, {"RTC Cross Roads", "Chikkadpally", 1.2},
        {"Chikkadpally", "Narayanaguda", 1.2}, {"Narayanaguda", "Sultan Bazar", 1.2},
        {"Sultan Bazar", "Osmania Medical College", 1.2}, {"MG Bus Station", "Salar Jung Museum", 1.2},
        {"Salar Jung Museum", "Charminar", 1.2}, {"Charminar", "Shalibanda", 1.2}, 
        {"Shalibanda", "Shamsherganj", 1.2}, {"Shamsherganj", "Jangammet", 1.2}, {"Jangammet", "Falaknuma", 1.2},
        {"Nagole", "Uppal", 1.2}, {"Uppal", "NGRI", 1.2}, {"NGRI", "Habsiguda", 1.2},
        {"Habsiguda", "Tarnaka", 1.2}, {"Tarnaka", "Lalaguda", 1.2}, {"Lalaguda", "Mettuguda", 1.2},
        {"Mettuguda", "Secunderabad", 1.2}, {"Parade Grounds", "Paradise", 1.2}, {"Paradise", "Begumpet", 1.2},
        {"Begumpet", "Ameerpet", 1.2}, {"Ameerpet", "Madhura Nagar", 1.2},
        {"Madhura Nagar", "Yusufguda", 1.2}, {"Yusufguda", "Jubilee Hills Checkpost", 1.2},
        {"Jubilee Hills Checkpost", "Jubilee Hills Road", 1.2}, {"Jubilee Hills Road", "COD", 1.2},
        {"COD", "Peddamma Temple", 1.2}, {"Peddamma Temple", "Madhapur", 1.2},
        {"Madhapur", "HITEC City", 1.2}, {"HITEC City", "Shilparamam", 1.2},
    
        // Additional connections
        {"Miyapur", "Kukatpally", 5.8}, {"Kukatpally", "Ameerpet", 8.0},
        {"Ameerpet", "Begumpet", 3.0}, {"Ameerpet", "Erragadda", 4.5},
        {"Secunderabad", "Begumpet", 3.8}, {"Secunderabad", "RTC Cross Roads", 5.0},
        {"Secunderabad", "Parade Grounds", 2.0}, {"RTC Cross Roads", "Narayanguda", 3.5},
        {"Narayanguda", "Charminar", 6.5}, {"Charminar", "Malakpet", 3.0},
        {"Charminar", "MG Bus Station", 3.0}, {"Nagole", "Habsiguda", 5.5},
        {"Habsiguda", "Mettuguda", 4.0}, {"Madhapur", "HITEC City", 2.5},
        {"Jubilee Hills Checkpost", "Banjara Hills", 4.0}, {"Banjara Hills", "Erragadda", 7.0},
        {"Lakdikapul", "Assembly", 1.5}, {"Lakdikapul", "Khairatabad", 2.0},
        {"Khairatabad", "Begumpet", 6.0}, {"Shilparamam", "Raidurg", 2.0}
    };

    for (const auto& connection : connections) {
        metroGraph.addEdge(get<0>(connection), get<1>(connection), get<2>(connection));
    }

    while (true) {
        string start, destination, input;
        vector<string> destinations;
        set<string> avoidStations;

        cout << "\nSelect an option:\n"
             << "1. Shortest path between two stations\n"
             << "2. Shortest path visiting multiple stations\n"
             << "3. Exit\n";

        getline(cin, input);

        if (input == "1") {
            cout << "Enter start station: ";
            getline(cin, start);

            cout << "Enter destination station: ";
            getline(cin, destination);

            cout << "Enter stations to avoid (comma-separated, leave blank if none): ";
            getline(cin, input);

            if (!input.empty()) {
                stringstream ss(input);
                string station;

                while (getline(ss, station, ',')) {
                    station = metroGraph.findStation(station);
                    if (!station.empty()) avoidStations.insert(station);
                }
            }

            start = metroGraph.findStation(start);
            destination = metroGraph.findStation(destination);

            if (start.empty() || destination.empty()) {
                cout << "Invalid station name(s).\n";
                continue;
            }

            metroGraph.findShortestPath(start, destination, avoidStations);

        } else if (input == "2") {
            cout << "Enter start station: ";
            getline(cin, start);

            cout << "Enter destinations (comma-separated): ";
            getline(cin, input);

            if (input.empty()) {
                cout << "Please specify at least one destination.\n";
                continue;
            }

            stringstream ss(input);
            string station;

            while (getline(ss, station, ',')) {
                station = metroGraph.findStation(station);
                if (!station.empty()) destinations.push_back(station);
            }

            if (destinations.empty()) {
                cout << "Invalid destination name(s).\n";
                continue;
            }

            cout << "Enter stations to avoid (comma-separated, leave blank if none): ";
            getline(cin, input);

            if (!input.empty()) {
                stringstream ss(input);

                while (getline(ss, station, ',')) {
                    station = metroGraph.findStation(station);
                    if (!station.empty()) avoidStations.insert(station);
                }
            }

            start = metroGraph.findStation(start);

            if (start.empty()) {
                cout << "Invalid start station name.\n";
                continue;
            }

            metroGraph.multipleDestinations(start, destinations, avoidStations);

        } else if (input == "3") {
            cout << "Exiting the program. Goodbye!\n";
            break;

        } else {
            cout << "Invalid option. Please try again.\n";
        }
    }

    return 0;
}
